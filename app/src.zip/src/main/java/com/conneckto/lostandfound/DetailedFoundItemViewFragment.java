package com.conneckto.lostandfound;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import com.conneckto.lostandfound.Util.Util;
import com.conneckto.lostandfound.dao.LostAndFoundDAOImpl;
import com.conneckto.lostandfound.model.Claims;
import com.conneckto.lostandfound.model.LostAndFound;

import java.util.Calendar;

/**
 * Created by suryaveer on 2016-05-26.
 */
public class DetailedFoundItemViewFragment extends Fragment {

    private LostAndFound lostAndFound;
    private LostAndFoundDAOImpl lostAndFoundDAO;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View v=inflater.inflate(R.layout.detailed_found_item_view, container, false);
        ViewHolder holder = new ViewHolder(v);
        /*TextView desc = (TextView)v.findViewById(R.id.descValueTextViewLIT);
        TextView place = (TextView)v.findViewById(R.id.placeValueTextViewLIT);
        TextView date = (TextView)v.findViewById(R.id.dateValueTextViewLIT);
        TextView itemType =(TextView)v.findViewById(R.id.itemValueTextViewLIT);
        TextView name = (TextView)v.findViewById(R.id.nameTextViewLIT);
        TextView stuClass = (TextView)v.findViewById(R.id.classValueTextViewLIT);
        TextView section = (TextView)v.findViewById(R.id.sectionValueTextViewLIT);
        TextView dateTitle = (TextView)v.findViewById(R.id.dateTextViewLIT);
        TextView placeTitle = (TextView)v.findViewById(R.id.placeTextViewLIT);
        TextView reportedBy = (TextView)v.findViewById(R.id.reportedByValueTextViewLIT);
        Button claimItemBtn =(Button) v.findViewById(R.id.claimItemButton);*/

        holder.dateTitle.setText(R.string.date_found_text);
        holder.placeTitle.setText(R.string.place_found_text);
        holder.desc.setText(lostAndFound.getDescription());
        holder.place.setText(lostAndFound.getReportedPlace());
        holder.date.setText(ApplicationContextProvider.getDateFormat().format(lostAndFound.getReportedDate()));
        holder.reporter.setText(lostAndFound.getReporterId() + "");
        holder.itemType.setText(lostAndFound.getItemType());
        holder.name.setText(lostAndFound.getName());
        holder.stuClass.setText(lostAndFound.getStudentClass()+"");
        holder.section.setText(lostAndFound.getSection());
        holder.claimItemBtn.setVisibility(View.VISIBLE);
        holder.claimItemBtn.setTag(lostAndFound);//pass the lostfound object as tag.
        holder.claimItemBtn.setOnClickListener(new CustomListener());
        /*claimItemBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                lostAndFoundDAO = new LostAndFoundDAOImpl();
                Claims claim = new Claims();
                claim.setClaimerId(ApplicationContextProvider.reporterID);
                claim.setClaimSubmission(Calendar.getInstance().getTime());
                claim.setItemId(lostAndFound.getItemId());
                lostAndFoundDAO.claimFoundItem(claim);
                Log.d("DetailedFoundItem", "Claiming item: " + lostAndFound.getItemId());
            }
        });*/

        return v;

    }
    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        Log.d("DetailedFoundItem","onActivityCreated");
        getView().setFocusableInTouchMode(true);
        getView().requestFocus();
        getView().setTag(Util.FOUND_FRAGMENT_TAG);
        getView().setOnKeyListener(new CustomListener(getContext()));
    }
    public void setLostAndFound(LostAndFound lostAndFound)
    {
        this.lostAndFound = lostAndFound;
    }
}
