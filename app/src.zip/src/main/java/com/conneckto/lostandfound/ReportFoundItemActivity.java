package com.conneckto.lostandfound;

import android.app.DatePickerDialog;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

import com.conneckto.lostandfound.Util.Util;
import com.conneckto.lostandfound.dao.LostAndFoundDAOImpl;
import com.conneckto.lostandfound.model.LostAndFound;

import java.text.ParseException;
import java.util.Calendar;

public class ReportFoundItemActivity extends AppCompatActivity {

    private int mYear, mMonth, mDay;
    EditText txtDate;
    private LostAndFoundDAOImpl lostAndFoundDAO;
    private Button button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.report_found_item);
        fillTemplate();
        txtDate = (EditText) findViewById(R.id.dateEditTextView);
        txtDate.setOnClickListener(new CustomListener(this));
        button = (Button) findViewById(R.id.submitButton);
        button.setTag(Util.ACTIVITY_FOUND);
        button.setOnClickListener(new CustomListener(this));
    }

    /*public void onClick(View v) {
        switch (v.getId()) {
            case R.id.dateEditTextView:
                final Calendar c = Calendar.getInstance();
                mYear = c.get(Calendar.YEAR);
                mMonth = c.get(Calendar.MONTH);
                mDay = c.get(Calendar.DAY_OF_MONTH);


                DatePickerDialog datePickerDialog = new DatePickerDialog(this,
                        new DatePickerDialog.OnDateSetListener() {

                            @Override
                            public void onDateSet(DatePicker view, int year,
                                                  int monthOfYear, int dayOfMonth) {

                                txtDate.setText(dayOfMonth + "-" + (monthOfYear + 1) + "-" + year);

                            }
                        }, mYear, mMonth, mDay);
                datePickerDialog.getDatePicker().setMaxDate(System.currentTimeMillis());
                datePickerDialog.show();
                break;
            case R.id.submitButton:
                LostAndFound lostAndFound = new LostAndFound();
                lostAndFound.setActivityType(Util.STATUS_FOUND);
                lostAndFound.setDescription(((TextView) findViewById(R.id.dateEditTextView)).getText().toString());
                lostAndFound.setItemType(((Spinner) findViewById(R.id.itemTypeSpinner)).getSelectedItem().toString());
                lostAndFound.setReportedPlace(((TextView) findViewById(R.id.placeEditTextView)).getText().toString());
                lostAndFound.setReportedPlace(((TextView) findViewById(R.id.placeEditTextView)).getText().toString());
                try {
                    lostAndFound.setReportedDate(ApplicationContextProvider.getDateFormat().parse(((TextView) findViewById(R.id.dateEditTextView)).getText().toString()));
                } catch (ParseException e) {
                    e.printStackTrace();
                }
                lostAndFound.setReporterId(ApplicationContextProvider.reporterID);
                lostAndFoundDAO = new LostAndFoundDAOImpl();
                lostAndFoundDAO.updateLostAndFoundItems(lostAndFound);
                break;
        }
    }*/

    private void fillTemplate() {
        TextView v = (TextView) findViewById(R.id.reportTitleTextView);
        v.setText(R.string.report_found_item_title);
        v = (TextView) findViewById(R.id.dateTextView);
        v.setText(R.string.date_found_text);
        v = (TextView) findViewById(R.id.placeTextView);
        v.setText(R.string.place_found_text);
    }
}
