package com.conneckto.lostandfound.Util;

/**
 * Created by suryaveer on 2016-05-26.
 */
public class Util {
    public static final String STATUS_LOST = "LOST";
    public static final String STATUS_FOUND = "FOUND";
    public static final String LOST_TAB_TEXT = "Lost Items";
    public static final String FOUND_TAB_TEXT = "Found Items";
    public static final String ACTIVITY_LOST = "LOST";
    public static final String ACTIVITY_FOUND = "FOUND";
    public static final String LOST_FRAGMENT_TAG = "LOST";
    public static final String FOUND_FRAGMENT_TAG = "FOUND";
}
