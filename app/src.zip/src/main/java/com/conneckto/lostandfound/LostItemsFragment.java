package com.conneckto.lostandfound;

import android.app.Activity;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.conneckto.lostandfound.model.LostAndFound;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by suryaveer on 2016-05-24.
 */
public class LostItemsFragment extends Fragment {

    private static List<LostAndFound> lostAndFoundList;
    private List<LostAndFound> tempList;
    private ListView listView;
    static int lostTabListViewId;
    private LinearLayout parent_layout;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.view_lost_item, container, false);
        lostTabListViewId = R.id.listViewLost;
        populateList(v);
        return v;
    }

    public void populateList(View v) {
        tempList = ApplicationContextProvider.getLostAndFoundList();
        int size = tempList.size();
        lostAndFoundList = new ArrayList<>();
        while (--size >= 0) {
            if (tempList.get(size).getActivityType().equalsIgnoreCase("lost"))
                lostAndFoundList.add(tempList.get(size));
        }
        ItemsAdapter itemsAdapter = new ItemsAdapter(getContext(), R.layout.list_items_template, lostAndFoundList);
        listView = (ListView) v.findViewById(R.id.listViewLost);
        listView.setAdapter(itemsAdapter);
        listView.setOnItemClickListener(new CustomListener(getContext()));
       /* listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Log.d("LostItemsFragment", view.getId()+ " "+ parent);
                parent_layout = (LinearLayout) getActivity().findViewById(R.id.parent_layout);
                parent_layout.setVisibility(View.GONE);

                FragmentManager fragmentManager = ((FragmentActivity)getContext()).getSupportFragmentManager();
                FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                DetailedLostItemViewFragment detailedLostItemViewFragment = new DetailedLostItemViewFragment();
                detailedLostItemViewFragment.setLostAndFound(lostAndFoundList.get(position));

                fragmentTransaction.add(R.id.detailed_fragment_container, detailedLostItemViewFragment, "LostFragment");
                fragmentTransaction.addToBackStack("LostFragment");
                fragmentTransaction.commit();
            }
        });*/

    }
    public static LostAndFound getLostItem(int index)
    {
        return lostAndFoundList.get(index);
    }


}
